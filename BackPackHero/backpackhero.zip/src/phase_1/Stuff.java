package phase_1;

public enum Stuff {
	WoodSword,
	CompositeBow,
	ShortArrow,
	LeatherCap,
	RoughBuckler,
	ElectricWand,
	ManaStone
}
