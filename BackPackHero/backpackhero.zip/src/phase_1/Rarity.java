package phase_1;

public enum Rarity {
	COMMON,
	UNCOMMON,
	RARE,
	LEGENDARY
}
