package fr.uge.backpackhero;

public enum Mode {
  // Les 4 états possibles du jeu
  EXPLORATION, COMBAT, PERDU, GAGNE 
}
