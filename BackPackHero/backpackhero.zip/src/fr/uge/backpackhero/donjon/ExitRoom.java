package fr.uge.backpackhero.donjon;

/**
 * La salle qui contient la porte de sortie.
 * Permet de passer à l'étage suivant.
 */
public record ExitRoom() implements Room {}