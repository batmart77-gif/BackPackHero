package fr.uge.backpackhero.donjon;

/**
 * Une salle avec un marchand.
 */
public record MerchantRoom() implements Room {
	
	public MerchantRoom {}
}