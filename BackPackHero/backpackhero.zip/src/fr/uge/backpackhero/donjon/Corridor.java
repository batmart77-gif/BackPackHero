package fr.uge.backpackhero.donjon;

/**
 * Un couloir vide.
 * Il ne se passe rien ici, on peut juste traverser.
 */
public record Corridor() implements Room {}