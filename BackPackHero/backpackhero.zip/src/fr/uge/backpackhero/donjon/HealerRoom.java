package fr.uge.backpackhero.donjon;

/**
 * Une salle avec un guérisseur.
 * Permet de se soigner contre de l'or.
 */
public record HealerRoom() implements Room {}