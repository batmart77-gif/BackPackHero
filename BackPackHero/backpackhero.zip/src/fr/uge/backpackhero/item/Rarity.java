package fr.uge.backpackhero.item;

public enum Rarity {
	COMMON,
	UNCOMMON,
	RARE,
	LEGENDARY, 
	CURSE
}
